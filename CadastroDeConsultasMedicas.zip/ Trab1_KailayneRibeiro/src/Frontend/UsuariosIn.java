/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Frontend;

import BackEnd.Conexao;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Cadastro
 */
public class UsuariosIn extends javax.swing.JDialog {

    private Conexao c;
    private String CodUsuario;
    private Login l;
    
    public UsuariosIn(String CodUsuario) {
        initComponents();
        this.setModal(true);
        this.l = new Login();
        this.c = new Conexao();
        this.CodUsuario = CodUsuario;
        this.c.setComboBox(cbbNivel, "TipoAcesso");
        
        txtSenha.setVisible(false);
        lblSenha.setVisible(false);
                        
        if (!CodUsuario.equals("0")) {

            txtSenha.setVisible(true);
            lblSenha.setVisible(true);
                
            this.setTitle("EDITAR");
            btnCadastrar.setText("EDITAR");
            
            try {
                
                String SQL = " SELECT * FROM listar_usuarios WHERE CodUsuario = " + CodUsuario;
                this.c.setResultSet(SQL);
                this.c.getResultSet().first();
                txtUsuario.setText(this.c.getResultSet().getString("Nome"));
                txtCpf.setText(this.c.getResultSet().getString("CPF"));
                cbbNivel.setSelectedItem(this.c.getResultSet().getString("Nivel"));  
                txtSenha.setText(this.c.getResultSet().getString("Senha"));
            }
            catch(SQLException e) {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
        }
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblNome = new javax.swing.JLabel();
        txtUsuario = new javax.swing.JTextField();
        lblCpf = new javax.swing.JLabel();
        lblSenha = new javax.swing.JLabel();
        txtCpf = new javax.swing.JFormattedTextField();
        btnCadastrar = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        cbbNivel = new javax.swing.JComboBox<>();
        txtSenha = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("NOVO USUÁRIO");

        lblNome.setText("NOME:");

        lblCpf.setText("CPF:");

        lblSenha.setText("SENHA:");

        try {
            txtCpf.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###.###.###-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        btnCadastrar.setText("CADASTRAR");
        btnCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastrarActionPerformed(evt);
            }
        });

        jLabel4.setText("NIVEL:");

        cbbNivel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbbNivelActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(164, 164, 164)
                        .addComponent(btnCadastrar))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblCpf)
                            .addComponent(lblNome))
                        .addGap(36, 36, 36)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, 302, Short.MAX_VALUE)
                            .addComponent(txtCpf)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(lblSenha))
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(cbbNivel, 0, 300, Short.MAX_VALUE)
                            .addComponent(txtSenha))))
                .addContainerGap(32, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNome)
                    .addComponent(txtUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCpf)
                    .addComponent(txtCpf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(cbbNivel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblSenha)
                            .addComponent(txtSenha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(btnCadastrar)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarActionPerformed
        // TODO add your handling code here:

        if (txtUsuario.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Informe o nome do usuário");
            txtUsuario.requestFocus();
            if (txtCpf.getText().equals("   .   .   -  ")) {
                JOptionPane.showMessageDialog(this, "Informe o CPF do usuário");
                txtSenha.requestFocus();
            }   if (cbbNivel.getSelectedIndex() < 0) {
                    JOptionPane.showMessageDialog(this, "Selecione um nível");
            }
        } else {
            String SQL;
            String Msg;

            if (this.CodUsuario.equals("0")) {
                try{
                    this.c.setResultSet("SELECT * FROM Usuario WHERE Nome = " + "'" + txtUsuario.getText() + "'");
                    boolean existe = this.c.getResultSet().first();
                        
                    if (existe == false){
                        Msg = "Registro adicionado com sucesso";
                        SQL = "INSERT INTO Usuario (Nome, CPF, Senha, CodTipoAcesso)  VALUES ("
                        + "'" + txtUsuario.getText() + "', "
                        + "'" + txtCpf.getText() + "', "
                        + "'" + txtCpf.getText() + "', "
                        + "'" + this.c.getCodigoComboBox(cbbNivel, "TipoAcesso") + "'"
                        + ")";

                        this.c.SQLExecute(SQL);
                        JOptionPane.showMessageDialog(this, Msg);
                        this.dispose();
 
                    } else {             
                        JOptionPane.showMessageDialog(this, "Nome de usuário definido já existente");
                        txtUsuario.setText("");
                        txtUsuario.requestFocus();
                    }
                } catch(SQLException e){
                    JOptionPane.showMessageDialog(this, e.getMessage());
                }
            } else {
                try{
                    this.c.setResultSet("SELECT * FROM Usuario WHERE Nome = " + "'" + txtUsuario.getText() + "'");
                    this.c.getResultSet().first();
                    boolean editado = this.c.getResultSet().getString("Nome") == txtUsuario.getText();
                    
                    if (editado == false){
                        
                        Msg = "Registro editado com sucesso";
                        SQL = "UPDATE Usuario SET "
                        + " Nome = '" + txtUsuario.getText() + "', "
                        + " CPF = '" + txtCpf.getText() + "', "
                        + " Senha = '" + txtSenha.getText() + "', "
                        + " CodTipoAcesso = '" + this.c.getCodigoComboBox(cbbNivel, "TipoAcesso") + "' "
                        + " WHERE CodUsuario = " + this.CodUsuario;
                    
                        this.c.SQLExecute(SQL);
                        JOptionPane.showMessageDialog(this, Msg);
                        this.dispose();
                        
                    } else { 
                        
                        JOptionPane.showMessageDialog(this, "Nome de usuário definido já existente");
                        txtUsuario.setText("");
                        txtUsuario.requestFocus();
                    }
                } catch(SQLException e){
                    JOptionPane.showMessageDialog(this, e.getMessage());
                }            
            }
        }
    }//GEN-LAST:event_btnCadastrarActionPerformed

    private void cbbNivelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbbNivelActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbbNivelActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCadastrar;
    private javax.swing.JComboBox<String> cbbNivel;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel lblCpf;
    private javax.swing.JLabel lblNome;
    private javax.swing.JLabel lblSenha;
    private javax.swing.JFormattedTextField txtCpf;
    private javax.swing.JPasswordField txtSenha;
    private javax.swing.JTextField txtUsuario;
    // End of variables declaration//GEN-END:variables
}
