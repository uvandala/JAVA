/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Frontend;

import BackEnd.Conexao;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Cadastro
 */
public class Usuarios extends javax.swing.JDialog {

    private Conexao c;
    
    public Usuarios() {
        initComponents();
        this.setModal(true);
        this.c = new Conexao();
        this.getListarUsuarios();
    }

    private void getListarUsuarios() {
        DefaultTableModel d = (DefaultTableModel) tblUsuarios.getModel();
        
        //Limpar linhas
        while(d.getRowCount() > 0)
            d.removeRow(0);
        
        this.c.setResultSet("SELECT * FROM listar_usuarios");
        
        try {
            if (this.c.getResultSet().first()) {
                do {
                    d.addRow(
                       new Object[] {
                           this.c.getResultSet().getString("CodUsuario") ,
                           this.c.getResultSet().getString("Nome"),
                           this.c.getResultSet().getString("CPF"),
                           this.c.getResultSet().getString("Nivel")
                       }
                    );                 
                } while(this.c.getResultSet().next());
            }
        }
        catch(SQLException e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        tblUsuarios = new javax.swing.JTable();
        btnNovo = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("USUÁRIOS");

        tblUsuarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "NOME", "CPF", "NIVEL"
            }
        ));
        jScrollPane2.setViewportView(tblUsuarios);

        btnNovo.setText("Novo");
        btnNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNovoActionPerformed(evt);
            }
        });

        btnExcluir.setText("Excluir");
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        btnEditar.setText("Editar");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(66, 66, 66)
                        .addComponent(btnNovo)
                        .addGap(18, 18, 18)
                        .addComponent(btnEditar)
                        .addGap(18, 18, 18)
                        .addComponent(btnExcluir)))
                .addContainerGap(18, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnNovo)
                    .addComponent(btnExcluir)
                    .addComponent(btnEditar))
                .addContainerGap(23, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNovoActionPerformed
        // TDO add your handling code here:
        new UsuariosIn("0").setVisible(true);
        this.getListarUsuarios();
    }//GEN-LAST:event_btnNovoActionPerformed

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
        // TODO add your handling code here:
        if (tblUsuarios.getRowCount() > 0) {
            if (tblUsuarios.getSelectedRowCount() > 0) {
                if (JOptionPane.showConfirmDialog(this,
                    "Confirmar exclusão do usuário?",
                    "Excluir",
                    JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                String m = String.valueOf(tblUsuarios.getValueAt(tblUsuarios.getSelectedRow(), 0));
                this.c.SQLExecute("DELETE FROM Usuario WHERE CodUsuario = " + m);
                this.getListarUsuarios();
            }
        }
        else
        JOptionPane.showMessageDialog(this, "Selecione um usuário");
        }
        else
        JOptionPane.showMessageDialog(this, "Não existem usuários cadastrados");
    }//GEN-LAST:event_btnExcluirActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        // TODO add your handling code here:
        if (tblUsuarios.getRowCount() > 0) {
            if (tblUsuarios.getSelectedRowCount() > 0) {
                String id = String.valueOf(tblUsuarios.getValueAt(tblUsuarios.getSelectedRow(), 0));
                new UsuariosIn(id).setVisible(true);
                this.getListarUsuarios();
            }
            else
            JOptionPane.showMessageDialog(this, "Selecione um usuário");
        }
        else
        JOptionPane.showMessageDialog(this, "Não há usuários cadastrados");
    }//GEN-LAST:event_btnEditarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnNovo;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tblUsuarios;
    // End of variables declaration//GEN-END:variables
}
