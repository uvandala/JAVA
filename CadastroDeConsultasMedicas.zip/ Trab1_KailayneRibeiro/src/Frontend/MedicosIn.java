/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Frontend;

import BackEnd.Conexao;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Kailayne
 */
public class MedicosIn extends javax.swing.JDialog {
    
    private String CodMedico;
    private Conexao c;

    public MedicosIn(String CodMedico) {
        initComponents();
        this.setModal(true);
        this.c = new Conexao();
        this.CodMedico = CodMedico;
        
        if (!CodMedico.equals("0")) {
            this.setTitle("EDITAR");
            btnCadastrar.setText("EDITAR");
            
            try {
                String SQL = " SELECT * FROM Medico WHERE CodMedico = " + CodMedico;
                this.c.setResultSet(SQL);
                this.c.getResultSet().first();
                txtMedico.setText(this.c.getResultSet().getString("Nome"));                              
            }
            catch(SQLException e) {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        txtMedico = new javax.swing.JTextField();
        btnCadastrar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("NOVO MÉDICO");

        jLabel1.setText("NOME:");

        btnCadastrar.setText("CADASTRAR");
        btnCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(jLabel1)
                        .addGap(22, 22, 22)
                        .addComponent(txtMedico, javax.swing.GroupLayout.PREFERRED_SIZE, 327, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(171, 171, 171)
                        .addComponent(btnCadastrar)))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(txtMedico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(btnCadastrar)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarActionPerformed
        // TODO add your handling code here:
        if (txtMedico.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Informar o nome do médico");
            txtMedico.requestFocus();
        }
        else {
            String SQL;
            String Msg;

            if (this.CodMedico.equals("0")) {
                Msg = "Registro adicionado com sucesso";
                SQL = "INSERT INTO Medico (Nome) " +
                        " VALUES ("
                             + "'" + txtMedico.getText() + "' " +
                        ")";                                                
            }
            else {
                Msg = "Registro editado com sucesso";
                SQL = "UPDATE Medico SET "
                        + " Nome = '" + txtMedico.getText() + "' " +           
                " WHERE CodMedico = " + this.CodMedico;
            }
            this.c.SQLExecute(SQL);
            JOptionPane.showMessageDialog(this, Msg);
            this.dispose();
        }
    }//GEN-LAST:event_btnCadastrarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCadastrar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JTextField txtMedico;
    // End of variables declaration//GEN-END:variables
}
