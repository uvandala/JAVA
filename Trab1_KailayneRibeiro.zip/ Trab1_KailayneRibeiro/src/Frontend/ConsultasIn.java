/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Frontend;

import BackEnd.Conexao;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Kailayne
 */
public class ConsultasIn extends javax.swing.JDialog {

    private Conexao c;
    private String Cod;
    
    
    public ConsultasIn(String Cod) {
        initComponents();
        this.setModal(true);
        this.c = new Conexao();
        this.Cod = Cod;
        
        this.c.setComboBox(cbbMedico, "Medico");
        this.c.setComboBox(cbbPaciente, "Paciente");
            
        if (!Cod.equals("0")) {
            this.setTitle("EDITAR");
            btnCadastrar.setText("EDITAR");
                        
            try {
                String SQL = " SELECT * FROM listar_consultas WHERE Consulta = " + Cod;
                this.c.setResultSet(SQL);
                this.c.getResultSet().first();
                txtData.setText(this.c.getResultSet().getString("DataConsulta")); 
                cbbMedico.setSelectedItem(this.c.getResultSet().getString("Medico"));     
                cbbPaciente.setSelectedItem(this.c.getResultSet().getString("Paciente"));     
                txtObs.setText(this.c.getResultSet().getString("Observacoes"));        
            }
            catch(SQLException e) {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnCadPaciente = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        txtData = new javax.swing.JFormattedTextField();
        jLabel3 = new javax.swing.JLabel();
        cbbMedico = new javax.swing.JComboBox<>();
        btnCadMedico = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        cbbPaciente = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtObs = new javax.swing.JTextArea();
        btnCadastrar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("NOVA CONSULTA");

        btnCadPaciente.setText("Novo");
        btnCadPaciente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadPacienteActionPerformed(evt);
            }
        });

        jLabel2.setText("DATA:");

        try {
            txtData.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("####-##-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDataActionPerformed(evt);
            }
        });

        jLabel3.setText("MÉDICO:");

        cbbMedico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbbMedicoActionPerformed(evt);
            }
        });

        btnCadMedico.setText("Novo");
        btnCadMedico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadMedicoActionPerformed(evt);
            }
        });

        jLabel4.setText("PACIENTE:");

        cbbPaciente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbbPacienteActionPerformed(evt);
            }
        });

        jLabel1.setText("OBSERVAÇÕES:");

        txtObs.setColumns(20);
        txtObs.setRows(5);
        jScrollPane1.setViewportView(txtObs);

        btnCadastrar.setText("CADASTRAR");
        btnCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnCadastrar)
                .addGap(209, 209, 209))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(txtData, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane1))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cbbMedico, javax.swing.GroupLayout.PREFERRED_SIZE, 327, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cbbPaciente, javax.swing.GroupLayout.PREFERRED_SIZE, 327, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnCadPaciente)
                                    .addComponent(btnCadMedico))))))
                .addGap(29, 29, 29))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtData, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(cbbMedico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCadPaciente))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(cbbPaciente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCadMedico))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(btnCadastrar)
                .addContainerGap(16, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnCadPacienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadPacienteActionPerformed
        // TODO add your handling code here:
        new MedicosIn("0").setVisible(true);
    }//GEN-LAST:event_btnCadPacienteActionPerformed

    private void btnCadMedicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadMedicoActionPerformed
        // TODO add your handling code here:
        new PacientesIn("0").setVisible(true);
    }//GEN-LAST:event_btnCadMedicoActionPerformed

    private void txtDataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDataActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDataActionPerformed

    private void btnCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarActionPerformed
        // TODO add your handling code here:
        
        
        if (txtData.getText().equals("    -  -  ")) {
            JOptionPane.showMessageDialog(this, "Informar a data da consulta");
            txtData.requestFocus();
        } else if (cbbMedico.getSelectedIndex() < 0) {
            JOptionPane.showMessageDialog(this, "Selecione um médico");
        } else if (cbbPaciente.getSelectedIndex() < 0) {
            JOptionPane.showMessageDialog(this, "Selecione um paciente");
        } else {

            String SQL;
            String Msg;
            
            if (this.Cod.equals("0")) {
                Msg = "Registro adicionado com sucesso";
                SQL = "INSERT INTO Consulta (DataConsulta, CodMedico, CodPaciente, Observacoes)  VALUES ("
                + "'" + txtData.getText() + "', "
                + "'" + this.c.getCodigoComboBox(cbbMedico, "Medico") + "', "
                + "'" + this.c.getCodigoComboBox(cbbPaciente, "Paciente") + "', "
                + "'" + txtObs.getText() + "'" +
                ")";
            }
            else {
                Msg = "Registro editado com sucesso";
                SQL = "UPDATE Consulta SET "
                + " DataConsulta = '" + txtData.getText() + "', "
                + " CodMedico = '" + this.c.getCodigoComboBox(cbbMedico, "Medico") + "', "
                + " CodPaciente = '" + this.c.getCodigoComboBox(cbbPaciente, "Paciente") + "', "
                + " Observacoes = '" + txtObs.getText() + "' " +
                " WHERE Consulta = " + this.Cod;
            }
            this.c.SQLExecute(SQL);
            JOptionPane.showMessageDialog(this, Msg);
            this.dispose();
        }  
    }//GEN-LAST:event_btnCadastrarActionPerformed

    private void cbbPacienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbbPacienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbbPacienteActionPerformed

    private void cbbMedicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbbMedicoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbbMedicoActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCadMedico;
    private javax.swing.JButton btnCadPaciente;
    private javax.swing.JButton btnCadastrar;
    private javax.swing.JComboBox<String> cbbMedico;
    private javax.swing.JComboBox<String> cbbPaciente;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JFormattedTextField txtData;
    private javax.swing.JTextArea txtObs;
    // End of variables declaration//GEN-END:variables
}
